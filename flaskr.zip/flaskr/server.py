#!/usr/bin/env python2.7

"""
Columbia W4111 Intro to databases
Example webserver
To run locally
    python server.py
Go to http://localhost:8111 in your browser
A debugger such as "pdb" may be helpful for debugging.
Read about it online.
"""

import os
import random
from sqlalchemy import *
from sqlalchemy.pool import NullPool
from flask import Flask, request, render_template, g, redirect, Response,session,flash



tmpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
app = Flask(__name__, template_folder=tmpl_dir)

#config
app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
USERNAME = 'admin'
PASSWORD = 'password'

#     DATABASEURI = "postgresql://ewu2493:foobar@w4111db.eastus.cloudapp.azure.com/ewu2493"
#
DATABASEURI = "postgresql://aaw2142:KHVCMG@w4111db.eastus.cloudapp.azure.com/aaw2142"

# This line creates a database engine that knows how to connect to the URI above
engine = create_engine(DATABASEURI)

@app.before_request
def before_request():
 
  try:
    g.conn = engine.connect()
  except:
    print "uh oh, problem connecting to database"
    import traceback; traceback.print_exc()
    g.conn = None

@app.teardown_request
def teardown_request(exception):
  """
  At the end of the web request, this makes sure to close the database connection.
  If you don't the database could run out of memory!
  """
  try:
    g.conn.close()
  except Exception as e:
    pass

#
@app.route('/')
def index():

  return render_template("index.html")

##Query function fetcall
def query_db(query, *args):
    cur = g.conn.execute(query, args)
    
    rv = cur.fetchall()
    
    cur.close()
    return rv  

#search groups
@app.route('/form',methods=['GET','POST'])
def form():
  if request.method == 'POST':
    search_name = str(request.form['element_1'])
    print (search_name)
    search_subject = str(request.form['element_2'])

    if search_name:
      if search_subject:
        cursor = query_db("SELECT is_private, subject, description, name FROM groupp WHERE groupp.name =%s and groupp.subject=%s", (search_name,search_subject))        
        results = []
        for result in cursor:
          results.append(result)  
         
        context = dict(data = results)   
        
        return render_template("testplate.html", **context)    
      elif search_name:
          
        cursor = query_db("SELECT is_private, subject, description, name FROM groupp WHERE groupp.name =%s;",(search_name))

        results = []
        for result in cursor:
          results.append(result) 
         
        context = dict(data = results)     
      
        return render_template("testplate.html", **context)  
    elif search_subject:
        cursor = query_db("SELECT is_private, subject, description, name FROM groupp WHERE groupp.subject =%s", (search_subject))
        results = []
        for result in cursor:
          results.append(result) 
        context = dict(data = results)
        return render_template("testplate.html", **context)
    else:
      return render_template("form.html")
  else: 
    return render_template("form.html")  
##discussions:
@app.route('/form2',methods=['GET','POST'])
def form2():
    if request.method == 'POST':
      search_name = str(request.form['element_1'])
      cursor = query_db("SELECT description, location FROM discussion WHERE discussion.goal =%s", (search_name))  
      results = []
      for result in cursor:
        results.append(result)  
         
      context = dict(data = results)   
      return render_template("testplate.html", **context)
    else: 
      return render_template("form2.html")  
#@user_registered.connect_via(app)
#def _after_registration_hook(sender, user, **extra):
#    sender.logger.info('user registered')
#create group
@app.route('/discussion',methods=['GET','POST'])
def discussion():
  #get discussions and their posts
  cursor = query_db("SELECT discussion.goal, post.post_text FROM discussion, post where post.did = discussion.did")
  results = []
  for result in cursor:
    results.append(result)  
         
  context = dict(data = results)   
  return render_template("testplate.html", **context)

#group creation
@app.route('/groupc',methods=['GET','POST'])
def createg():
 if request.method == 'POST':
    a = str(request.form['element_1'])
    b = str(request.form['element_2'])
    c= str(request.form['element_3'])
    rand = random.randint(50,150)
    g.conn.execute('INSERT INTO groupp VALUES(%s,null,%s,%s,%s)',(rand,b,c,a))
   
    return render_template('success.html')
 else: 
   return render_template("groupc.html") 
#join group
@app.route('/groupj',methods =['GET','POST'])
def join():
  if request.method == 'POST':
   search_name = str(request.form['element_1'])
   your_name = str(request.form['element_2'])
   your_id = str(request.form['element_3'])
     
     
   g.conn.execute('INSERT INTO Student VALUES(%s,%s)',(your_name,your_id))
   b = g.conn.execute("SELECT groupp.gid FROM groupp WHERE groupp.name = %s",(search_name))
   h = []
   for item in b:
    h.append(item[0])
   g.conn.execute('INSERT INTO joinn VALUES (%s ,%s)', (your_id,h[0]))
    
   return render_template('success.html')
  else:
  
    return render_template('groupj.html')
    #search for a group to join
  
#my_page
#show my groups and discussions ordering by most recent 

@app.route('/my_page',methods=['GET', 'POST'])
def my_page():

#find groups on session['username']
    cursor = query_db("SELECT groupp.name,student.name from joinn, groupp, student where groupp.gid=joinn.gid and joinn.sid = student.sid and student.name ='Prez Bo'") 
    results = []
    for result in cursor:
      results.append(result) 
    context = dict(groups = results)     

    return render_template ('my_page.html', **context)
# query groups and discussions by username
#post to discussion

#@app.route('/post', methods = ['GET','POST'])
#def post():
#
#   discussion = str(request.form['element_1'])
#   your_name = str(request.form['element_2'])
#   text   = str(request.form['element_3'])
# 
#login
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin':
            error = 'Invalid username'
        elif request.form['password'] != 'password':
            error = 'Invalid password'
        else:
            session['username'] = request.form['username']
            session['logged_in'] = True
            flash('You were logged in')
            return redirect ("http://23.101.135.24:8111/my_page")
    else:
      return render_template('login.html')

#logout
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('You were logged out')
    return render_template('index.html')
#checkif logged in

    if not session.get('logged_in'):
        abort(401)



#join group
def join_group():
  if not session.get('logged_in'):
    abort(401)
  else: 
    return render_template ('/my_page')
# 

if __name__ == "__main__":
  import click

  @click.command()
  @click.option('--debug', is_flag=True)
  @click.option('--threaded', is_flag=True)
  @click.argument('HOST', default='0.0.0.0')
  @click.argument('PORT', default=8111, type=int)
  def run(debug, threaded, host, port):
    """
    This function handles command line parameters.
    Run the server using
        python server.py
    Show the help text using
        python server.py --help
    """

    HOST, PORT = host, port
    print "running on %s:%d" % (HOST, PORT)
    app.run(host=HOST, port=PORT, debug=debug, threaded=threaded)


  run()